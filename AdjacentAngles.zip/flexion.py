import numpy as np
import quaternion
from datetime import datetime

def quaternion_from_line(line):
    parts = line.strip().split(' ')
    date_str, time_str, quaternion_str = parts[0], parts[1], parts[2]

    # Combine date and time strings and convert to datetime
    timestamp_str = f"{date_str} {time_str}"
    timestamp = datetime.strptime(timestamp_str, "%m/%d/%y %H:%M:%S.%f")

    # Convert quaternion components to float
    q_components = [float(x) for x in quaternion_str.split(',')]

    # Create quaternion with x, y, z, w order
    q = quaternion.quaternion(q_components[3], q_components[0], q_components[1], q_components[2])

    return timestamp, q

def calculate_ranges(sensor_quaternions):
    flexion = []
    extension = []
    lateral_flexion = []
    rotation = []

    for timestamp, q in sensor_quaternions.items():
        # Convert quaternion to Euler angles
        euler_angles = quaternion_to_euler(q)

        # Update ranges
        flexion.append(euler_angles[0])
        extension.append(-euler_angles[0])
        lateral_flexion.append(euler_angles[1])
        rotation.append(euler_angles[2])

    # Calculate ranges
    flexion_range = (min(flexion), max(flexion))
    extension_range = (min(extension), max(extension))
    lateral_flexion_range = (min(lateral_flexion), max(lateral_flexion))
    rotation_range = (min(rotation), max(rotation))

    return flexion_range, extension_range, lateral_flexion_range, rotation_range

def quaternion_to_euler(q):
    # Convert quaternion to Euler angles (in degrees)
    roll = np.arctan2(2 * (q.y * q.z + q.x * q.w), 1 - 2 * (q.x**2 + q.y**2))
    pitch = np.arcsin(2 * (q.x * q.z - q.y * q.w))
    yaw = np.arctan2(2 * (q.x * q.y + q.z * q.w), 1 - 2 * (q.y**2 + q.z**2))
    return np.degrees(np.array([roll, pitch, yaw]))

# Prompt the user for the file paths
file_paths = [input(f"Enter the path to the input file for sensor {i+1}: ") for i in range(3)]

try:
    sensor_quaternions = [{} for _ in range(3)]

    # Read sensor quaternions from the text files
    for i, file_path in enumerate(file_paths):
        with open(file_path, 'r') as file:
            lines = file.readlines()
            sensor_quaternions[i] = {timestamp: q for timestamp, q in map(quaternion_from_line, lines)}

    # Calculate ranges for each sensor
    ranges = [calculate_ranges(sensor_quaternion) for sensor_quaternion in sensor_quaternions]

    # Print and save results to a new text file
    output_file_path = 'output_angle_ranges.txt'

    with open(output_file_path, 'w') as output_file:
        output_file.write("Sensor\t\t\t\tFlexion\t\tExtension\t\tLateral Flexion\tRotation\n")
        for i, (flexion_range, extension_range, lateral_flexion_range, rotation_range) in enumerate(ranges):
            output_file.write(f"Sensor {i+1}\t\t\t\t{flexion_range}\t\t{extension_range}\t\t{lateral_flexion_range}\t\t{rotation_range}\n")

    print(f"Angle ranges saved to {output_file_path}")

except FileNotFoundError:
    print("File not found. Please check the file paths and try again.")
except Exception as e:
    print(f"An error occurred: {e}")
