import numpy as np
import quaternion
from datetime import datetime

def quaternion_from_line(line):
    """
    Convert a line from the text file to a timestamp and a quaternion.
    """
    parts = line.strip().split(' ')
    date_str, time_str, quaternion_str = parts[0], parts[1], parts[2]

    # Combine date and time strings and convert to datetime
    timestamp_str = f"{date_str} {time_str}"
    timestamp = datetime.strptime(timestamp_str, "%m/%d/%y %H:%M:%S.%f")

    # Convert quaternion components to float
    q_components = [float(x) for x in quaternion_str.split(',')]

    # Create quaternion with x, y, z, w order
    q = quaternion.quaternion(q_components[3], q_components[0], q_components[1], q_components[2])

    return timestamp, q

def calculate_relative_euler(sensor_quaternions):
    """
    Calculate relative Euler angles between consecutive sensor readings.
    """
    relative_eulers = []
    for i in range(1, len(sensor_quaternions)):
        q_relative = sensor_quaternions[i][1] * sensor_quaternions[i-1][1].conjugate()
        timestamp_relative = sensor_quaternions[i][0]
        euler_angles = quaternion_to_euler(q_relative)
        relative_eulers.append((timestamp_relative, euler_angles))

    return relative_eulers

def quaternion_to_euler(q):
    """
    Convert quaternion to relative Euler angles (XYZ rotation order).
    """
    roll = np.arctan2(2 * (q.y * q.z + q.x * q.w),
                      1 - 2 * (q.x**2 + q.y**2))
    pitch = np.arcsin(2 * (q.x * q.z - q.y * q.w))
    yaw = np.arctan2(2 * (q.x * q.y + q.z * q.w),
                     1 - 2 * (q.y**2 + q.z**2))
    return np.degrees(np.array([roll, pitch, yaw]))

# Prompt the user for the file path
file_path_sensor = input("Enter the path to the input file for the sensor: ")

try:
    # Read sensor quaternions from the text file
    with open(file_path_sensor, 'r') as file:
        lines_sensor = file.readlines()

    sensor_quaternions = [quaternion_from_line(line) for line in lines_sensor]

    # Calculate relative Euler angles
    relative_eulers = calculate_relative_euler(sensor_quaternions)

    # Print and save results to a new text file
    output_file_path = 'output_relative_angles.txt'  # Replace with the desired output file path

    with open(output_file_path, 'w') as output_file:
        output_file.write("Timestamp\t\t\t\t\t\tRoll\t\t\tPitch\t\t\tYaw\n")
        for timestamp, euler_angles in relative_eulers:
            output_file.write(f"{timestamp}\t\t\t{euler_angles[0]}\t{euler_angles[1]}\t{euler_angles[2]}\n")

    print(f"Relative Euler angles saved to {output_file_path}")

except FileNotFoundError:
    print("File not found. Please check the file path and try again.")
except Exception as e:
    print(f"An error occurred: {e}")
