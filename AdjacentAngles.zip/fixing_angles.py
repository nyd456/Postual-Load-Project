import quaternion
import numpy as np
from datetime import datetime

def quaternion_from_line(line):
    parts = line.strip().split(' ')
    if len(parts) < 3:
        return None, None  # Skip lines that don't have enough parts

    time_str, quaternion_str = parts[1], parts[2]

    try:
        # Convert time string to datetime, ignoring date part
        timestamp = datetime.strptime(time_str, "%H:%M:%S.%f")

        # Convert quaternion components to float
        q_components = [float(x) for x in quaternion_str.split(',')]

        # Create quaternion with w, x, y, z order
        q = quaternion.quaternion(q_components[3], q_components[0], q_components[1], q_components[2])

        return timestamp, q
    except (ValueError, IndexError) as e:
        print(f"Error parsing line: {line.strip()}")
        print(f"Error message: {e}")
        print("Exception handled.")
        return None, None  # Skip lines that cannot be parsed as timestamps or quaternions


def interpolate_quaternions(timestamps, quaternions, target_timestamps):
    interpolated_quaternions = []
    for target_timestamp in target_timestamps:
        # Find nearest timestamps
        idx = np.searchsorted(timestamps, target_timestamp)
        if idx == 0:
            q = quaternions[0]
        elif idx == len(timestamps):
            q = quaternions[-1]
        else:
            t1, t2 = timestamps[idx - 1], timestamps[idx]
            q1, q2 = quaternions[idx - 1], quaternions[idx]
            # Linear interpolation
            alpha = (target_timestamp - t1) / (t2 - t1)
            q = quaternion.slerp_evaluate(q1, q2, alpha)
        interpolated_quaternions.append(q)
    return interpolated_quaternions

def calculate_relative_angles(sensor_quaternions):
    relative_angles = []
    for i in range(len(sensor_quaternions) - 1):
        q1 = sensor_quaternions[i]
        q2 = sensor_quaternions[i + 1]
        rel_q = q2 * q1.inverse()
        euler_angles = rel_q.to_euler(degrees=True)
        relative_angles.append(euler_angles)
    return relative_angles

def process_files(file_paths):
    sensor_timestamps = []
    sensor_quaternions = []
    for file_path in file_paths:
        with open(file_path, 'r') as file:
            print(f"Processing file: {file_path}")
            next(file)  # Skip the first line
            timestamps = []
            quaternions = []
            for line in file:
                timestamp, quaternion = quaternion_from_line(line)
                if timestamp is not None and quaternion is not None:
                    timestamps.append(timestamp)
                    quaternions.append(quaternion)
            sensor_timestamps.append(timestamps)
            sensor_quaternions.append(quaternions)

    # Find common timestamps
    common_timestamps = np.sort(np.unique(np.concatenate(sensor_timestamps)))

    # Interpolate quaternions for common timestamps
    interpolated_quaternions = []
    for i in range(len(file_paths)):
        interpolated_quaternions.append(interpolate_quaternions(sensor_timestamps[i], sensor_quaternions[i], common_timestamps))

    # Calculate relative angles
    relative_angles = []
    for quats in zip(*interpolated_quaternions):
        relative_angles.append(calculate_relative_angles(quats))

    print("Relative Angles:")
    for i, angles in enumerate(relative_angles, start=1):
        print(f"Sensor {i}-{i+1}:")
        for j, (yaw, pitch, roll) in enumerate(angles, start=1):
            print(f"  Frame {j}: Yaw={yaw:.2f}, Pitch={pitch:.2f}, Roll={roll:.2f}")

# Example usage
file_paths = [
    input("Enter file path for sensor 1: "),
    input("Enter file path for sensor 2: "),
    input("Enter file path for sensor 3: ")
]
process_files(file_paths)
