import numpy as np
import quaternion
from datetime import datetime


def quaternion_from_line(line):
    """
    Convert a line from the text file to a timestamp and a quaternion.
    """
    parts = line.strip().split(' ')
    date_str, time_str, quaternion_str = parts[0], parts[1], parts[2]

    # Combine date and time strings and convert to datetime
    timestamp_str = f"{date_str} {time_str}"
    timestamp = datetime.strptime(timestamp_str, "%m/%d/%y %H:%M:%S.%f")

    # Convert quaternion components to float
    q_components = [float(x) for x in quaternion_str.split(',')]

    # Create quaternion with x, y, z, w order
    q = quaternion.quaternion(q_components[3], q_components[0], q_components[1], q_components[2])

    return timestamp, q


def calculate_relative_euler(sensor1_quaternions, sensor2_quaternions):
    """
    Calculate relative Euler angles between corresponding sensor readings.
    """
    relative_eulers = []
    min_length = min(len(sensor1_quaternions), len(sensor2_quaternions))

    for i in range(1, min_length):
        q1_relative = sensor1_quaternions[i][1] * sensor1_quaternions[i - 1][1].conjugate()
        q2_relative = sensor2_quaternions[i][1] * sensor2_quaternions[i - 1][1].conjugate()

        timestamp_relative = sensor1_quaternions[i][0]

        euler_angles = quaternion_to_euler(q1_relative, q2_relative)
        relative_eulers.append((timestamp_relative, euler_angles))

    return relative_eulers


def quaternion_to_euler(q1, q2):
    """
    Convert quaternions to relative Euler angles (ZYX rotation order).
    """
    q_relative = q1 * q2.conjugate()
    yaw = np.arctan2(2 * (q_relative.y * q_relative.z + q_relative.x * q_relative.w),
                     1 - 2 * (q_relative.x ** 2 + q_relative.y ** 2))
    pitch = np.arcsin(2 * (q_relative.x * q_relative.z - q_relative.y * q_relative.w))
    roll = np.arctan2(2 * (q_relative.x * q_relative.y + q_relative.z * q_relative.w),
                      1 - 2 * (q_relative.y ** 2 + q_relative.z ** 2))
    return np.degrees(np.array([yaw, pitch, roll]))


# Prompt the user for the file paths
file_path_sensor1 = input("Enter the path to the input file for sensor 1: ")
file_path_sensor2 = input("Enter the path to the input file for sensor 2: ")

try:
    # Read sensor quaternions from the text files
    with open(file_path_sensor1, 'r') as file:
        lines_sensor1 = file.readlines()

    with open(file_path_sensor2, 'r') as file:
        lines_sensor2 = file.readlines()

    sensor1_quaternions = [quaternion_from_line(line) for line in lines_sensor1]
    sensor2_quaternions = [quaternion_from_line(line) for line in lines_sensor2]

    # Calculate relative Euler angles
    relative_eulers = calculate_relative_euler(sensor1_quaternions, sensor2_quaternions)

    # Print and save results to a new text file
    output_file_path = 'output_relative_angles.txt'  # Replace with the desired output file path

    with open(output_file_path, 'w') as output_file:
        output_file.write("Timestamp\t\t\tYaw\t\t\t\tPitch\t\t\t\tRoll\n")
        for timestamp, euler_angles in relative_eulers:
            output_file.write(f"{timestamp}\t\t\t{euler_angles[0]}\t{euler_angles[1]}\t{euler_angles[2]}\n")

    print(f"Relative Euler angles saved to {output_file_path}")

except FileNotFoundError:
    print("File not found. Please check the file paths and try again.")
except Exception as e:
    print(f"An error occurred: {e}")
