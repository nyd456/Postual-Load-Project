import numpy as np


def read_quaternions(file_path):
    quaternions = []
    with open(file_path, 'r') as file:
        next(file)  # Skip the first line
        for line in file:
            parts = line.strip().split(' ')
            if len(parts) >= 3:  # Ensure there are enough elements in the parts list
                timestamp = parts[1]
                quaternion = list(map(float, parts[2].split(',')))
                quaternions.append((timestamp, quaternion))
            else:
                print("Warning: Skipping line with insufficient data:", line)
    return quaternions


def interpolate_quaternion(q1, q2, ratio):
    q = (1 - ratio) * np.array(q1) + ratio * np.array(q2)
    # Normalize the interpolated quaternion
    q /= np.linalg.norm(q)
    return q.tolist()


def quaternion_to_anatomical_angles(quaternion):
    q = np.array(quaternion)
    qw, qx, qy, qz = q / np.linalg.norm(q)  # Normalize the quaternion
    # Conversion to anatomical angles (yaw, pitch, roll) in degrees
    yaw = np.degrees(np.arctan2(2 * (qw * qz + qx * qy), 1 - 2 * (qy ** 2 + qz ** 2)))
    pitch = np.degrees(np.arcsin(2 * (qw * qx - qy * qz)))
    roll = np.degrees(np.arctan2(2 * (qw * qy + qz * qx), 1 - 2 * (qx ** 2 + qz ** 2)))
    return [yaw, pitch, roll]


def calculate_relative_anatomical_angles(sensor1_data, sensor2_data, sensor3_data):
    relative_angles = []

    # Calculate relative angles for Sensor 1 to Sensor 2
    for i in range(min(len(sensor1_data), len(sensor2_data))):
        timestamp1, quaternion1 = sensor1_data[i]
        timestamp2, quaternion2 = sensor2_data[i]

        # Check if timestamps match between sensor 1 and sensor 2, otherwise interpolate
        if timestamp1 != timestamp2:
            ratio = (float(timestamp1.split(':')[2]) - 50) / (
                        float(timestamp2.split(':')[2]) - 50)  # Assuming 50 milliseconds
            quaternion2 = interpolate_quaternion(quaternion1, quaternion2, ratio)
            timestamp2 = timestamp1  # Use timestamp from sensor1 for consistency

        angles1 = quaternion_to_anatomical_angles(quaternion1)
        angles2 = quaternion_to_anatomical_angles(quaternion2)

        relative_angle_1_2 = np.array(angles2) - np.array(angles1)
        relative_angles.append((timestamp1, relative_angle_1_2, "Sensor 1 to Sensor 2"))

    # Calculate relative angles for Sensor 1 to Sensor 3
    for i in range(min(len(sensor1_data), len(sensor3_data))):
        timestamp1, quaternion1 = sensor1_data[i]
        timestamp3, quaternion3 = sensor3_data[i]

        # Check if timestamps match between sensor 1 and sensor 3, otherwise interpolate
        if timestamp1 != timestamp3:
            ratio = (float(timestamp1.split(':')[2]) - 50) / (
                        float(timestamp3.split(':')[2]) - 50)  # Assuming 50 milliseconds
            quaternion3 = interpolate_quaternion(quaternion1, quaternion3, ratio)
            timestamp3 = timestamp1  # Use timestamp from sensor1 for consistency

        angles1 = quaternion_to_anatomical_angles(quaternion1)
        angles3 = quaternion_to_anatomical_angles(quaternion3)

        relative_angle_1_3 = np.array(angles3) - np.array(angles1)
        relative_angles.append((timestamp1, relative_angle_1_3, "Sensor 1 to Sensor 3"))

    # Calculate relative angles for Sensor 2 to Sensor 3
    for i in range(min(len(sensor2_data), len(sensor3_data))):
        timestamp2, quaternion2 = sensor2_data[i]
        timestamp3, quaternion3 = sensor3_data[i]

        # Check if timestamps match between sensor 2 and sensor 3, otherwise interpolate
        if timestamp2 != timestamp3:
            ratio = (float(timestamp2.split(':')[2]) - 50) / (
                        float(timestamp3.split(':')[2]) - 50)  # Assuming 50 milliseconds
            quaternion3 = interpolate_quaternion(quaternion2, quaternion3, ratio)
            timestamp3 = timestamp2  # Use timestamp from sensor2 for consistency

        angles2 = quaternion_to_anatomical_angles(quaternion2)
        angles3 = quaternion_to_anatomical_angles(quaternion3)

        relative_angle_2_3 = np.array(angles3) - np.array(angles2)
        relative_angles.append((timestamp2, relative_angle_2_3, "Sensor 2 to Sensor 3"))

    return relative_angles


def save_to_txt(file_path, data):
    with open(file_path, 'w') as file:
        for timestamp, angles, label in data:
            file.write(f"Timestamp: {timestamp}\n")
            file.write(f"Relative angles {label}: {angles}\n\n")


# Example usage
sensor1_data = read_quaternions(r'C:\Users\danie\Downloads\THESIS_DATA\Amy\Amy\1\03-21-24 13-37-10\data.txt')
sensor2_data = read_quaternions(r'C:\Users\danie\Downloads\THESIS_DATA\Amy\Amy\2\0X-15-XX 23-39-38\data.txt')
sensor3_data = read_quaternions(r'C:\Users\danie\Downloads\THESIS_DATA\Amy\Amy\3\01-01-04 12-26-18\data.txt')

relative_angles = calculate_relative_anatomical_angles(sensor1_data, sensor2_data, sensor3_data)

output_file_name = input("Enter the output file name (without extension): ")

output_file_path = output_file_name + "_combined.txt"

save_to_txt(output_file_path, relative_angles)

print(f"Output saved to '{output_file_path}'.")
